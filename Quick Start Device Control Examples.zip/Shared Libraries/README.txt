For these example applications to compile you will need to manually copy the DLLs
from your Kineses install folder to the "Shared Libraries" folder.

You do not need to copy all of the DLLs, however, to get up and running quickly we
recommend you do. Please refer to the Kinesis API documentation for the relevant
device(s) if you wish to be more selective about which DLLs you copy.
